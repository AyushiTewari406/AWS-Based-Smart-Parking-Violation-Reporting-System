# AWS-Based Smart Parking Violation Reporting System

A college project: a serverless AWS backend, a React frontend, and AWS cloud
infrastructure for reporting, reviewing, and fining parking violations on
campus.

## Folder structure

```
AWS_Smart_Parking_Violation/
├── backend/        Serverless API (AWS Lambda + API Gateway), written in
│                    Node.js, with AWS CDK infrastructure-as-code. See
│                    backend/infrastructure/README.md for deploy steps.
├── frontend/        React (Vite) web app ("Smart Park"). Currently runs on
│                    built-in mock data — see docs/ for details.
└── docs/
    ├── Smart_Parking_Full_Project_Documentation.docx
    │       The full writeup: architecture, every backend file explained
    │       with code screenshots, the frontend's components, AWS console
    │       screenshots, a live working demo of the app, and — most
    │       importantly — an honest section on what is NOT yet connected
    │       between the three parts (API path mismatches, missing DynamoDB
    │       indexes, mock vs. real API, etc.) and exactly what to do about
    │       each one.
    └── aws-setup-notes/
            The AWS console setup notes (region, DynamoDB tables, S3
            bucket, IAM role) as recorded by the teammate who did that
            work directly in the AWS console.
```

## Before you present or submit this

Read `docs/Smart_Parking_Full_Project_Documentation.docx`, especially
Section 7 ("Integration Status and Known Gaps"). The backend, frontend,
and AWS infrastructure each work on their own and have been verified
independently, but they are not wired together yet — the frontend still
runs on mock data, the backend has not been deployed with `cdk deploy`,
and there are a few concrete mismatches (API paths, violation categories,
missing database indexes) that need resolving first. That section gives
you a checklist and exact steps.

## Quick start

**Backend:** see `backend/infrastructure/README.md` for what `cdk deploy`
creates and the steps to deploy it.

**Frontend:**
```
cd frontend
npm install
npm run dev
```
It will run immediately against built-in mock data (`USE_MOCK_API = true`
in `src/services/api.js`).
