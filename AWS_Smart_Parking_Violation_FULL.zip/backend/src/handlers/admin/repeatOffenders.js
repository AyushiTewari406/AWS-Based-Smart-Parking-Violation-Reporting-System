import { withErrorHandling, success } from "../../utils/responses.js";
import { requireAdmin } from "../../middleware/authMiddleware.js";
import { getAllViolations } from "../../repositories/violationRepository.js";
import { VIOLATION_STATUS } from "../../utils/constants.js";

// Groups violations by vehicle so the admin dashboard can show a repeat
// offenders list. Like the other two admin reports (location-wise,
// monthly-stats), this scans the whole table — acceptable at this
// project's scale, same documented tradeoff as those two.
//
// Note: this counts ALL violations ever reported for a vehicle (any
// status), not just the recent-verified count the real-time repeat-
// offender flag on a new report uses (see repeatViolationService.js).
// That is intentional here — this is a historical report, not the
// enforcement check.
export const handler = withErrorHandling(async (event) => {
  requireAdmin(event);
  const violations = await getAllViolations();

  const byVehicle = new Map();
  for (const v of violations) {
    const existing = byVehicle.get(v.vehicleNumber) || {
      vehicleNumber: v.vehicleNumber,
      vehicleId: v.vehicleId,
      count: 0,
      totalFines: 0,
      verifiedCount: 0,
    };
    existing.count += 1;
    existing.totalFines += v.fine || 0;
    if (v.status === VIOLATION_STATUS.VERIFIED) existing.verifiedCount += 1;
    byVehicle.set(v.vehicleNumber, existing);
  }

  const report = Array.from(byVehicle.values())
    .filter((entry) => entry.count >= 2)
    .sort((a, b) => b.count - a.count);

  return success(report);
});
