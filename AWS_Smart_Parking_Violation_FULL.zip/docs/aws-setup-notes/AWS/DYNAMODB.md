# DynamoDB Work Completed

## Region
`ap-south-1`

## Tables

| Table | Primary Key | Type |
|---|---|---|
| ParkingUsers | userId | String |
| ParkingVehicles | vehicleId | String |
| ParkingViolations | violationId | String |
