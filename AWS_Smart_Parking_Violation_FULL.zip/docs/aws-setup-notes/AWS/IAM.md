# IAM Work Completed

## Role

```text
SmartParkingLambdaRole
```

## Policies attached

```text
AmazonDynamoDBFullAccess
AmazonS3FullAccess
AWSLambdaBasicExecutionRole
```

Purpose:

- DynamoDB access for the future Lambda
- S3 access for evidence storage
- CloudWatch logging for Lambda
