# Smart Parking Violation Reporting System
## Person 3 — Work Completed So Far

This file contains ONLY the AWS work completed so far by Person 3.

## 1. AWS Region

Selected AWS region:

```text
Asia Pacific (Mumbai)
ap-south-1
```

## 2. DynamoDB

The following DynamoDB tables were set up/planned as part of the AWS infrastructure work:

### ParkingUsers
```text
Primary key: userId
Type: String
```

### ParkingVehicles
```text
Primary key: vehicleId
Type: String
```

### ParkingViolations
```text
Primary key: violationId
Type: String
```

## 3. S3

S3 was set up/planned for storing parking-violation evidence images.

Structure:

```text
<evidence-bucket>/
└── evidence/
```

The evidence bucket is intended to remain private.

## 4. IAM

IAM role created:

```text
SmartParkingLambdaRole
```

Permissions successfully attached:

```text
AmazonDynamoDBFullAccess
AmazonS3FullAccess
AWSLambdaBasicExecutionRole
```

These permissions allow the future Lambda backend to:
- access DynamoDB
- access S3
- write Lambda logs to CloudWatch

## 5. Evidence / Screenshot

The included screenshot shows the IAM role permissions after the DynamoDB, S3, and Lambda basic execution policies were attached.

## 6. Current Status

Completed:

- AWS region selected
- DynamoDB infrastructure setup
- S3 infrastructure setup
- IAM role created
- DynamoDB permission attached
- S3 permission attached
- Lambda basic execution / CloudWatch logging permission attached

Not included in this file because they have NOT been completed yet:

- Lambda creation
- API Gateway
- API routes
- CORS
- Lambda-to-DynamoDB testing
- Lambda-to-S3 testing
- Frontend integration
- End-to-end testing

No AWS passwords, access keys, secret keys, or other credentials are included.
